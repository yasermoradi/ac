<?php
/**
 * @copyright 2015 Contentful GmbH
 * @license   MIT
 */

namespace Contentful\Delivery;

interface EntryInterface extends \JsonSerializable
{
}
